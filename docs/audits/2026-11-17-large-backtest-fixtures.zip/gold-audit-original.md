# Phase 4：结果前独立 Gold 审阅

## Review

### Correct：覆盖与边界

已逐条阅读全部 **160 个问题、64 条虚构记录**，核对问题、项目范围、`expected_all`、`forbidden`、理由及完整记录。非抽样。

- Lane A：32 条记录；80 个问题；40 中文、40 英文；29 个非空项目问题。
- Lane B：32 条记录；80 个问题；40 中文、40 英文；28 个非空项目问题。
- 每 lane：24 global、4 north、4 south；8 个核心主题。
- 每 lane 类别数：direct 16、paraphrase 16、multi_intent 16、conditional 8、no_answer 16、ambiguous 8。
- 合计：112 个正例、48 个空 `expected_all` 案例。
- 每 lane 的 no_answer：8 个主题内缺失属性、4 个错误项目范围、4 个无关问题。
- 手工核对未发现缺号、重复 ID、完全相同问题、正例引用不存在记录、正例跨项目引用。
- 未发现需要合并的重复意图。不同项目、条件、属性及多意图组合存在复用，但不能据此认定重复膨胀。
- 项目间冲突均有范围区分；未发现同一适用范围内互斥事实。
- 32 个 no_answer 均不能从各自允许范围得到完整答案。Lane A/q065 首个范围判断可部分回应，但要求的 north 颜色仍不可得，未列为错误负例。

判断依据：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/author-spec.md:12` 要求按完整记录判断支持；ambiguous 应缺少选择支持记录所需的实体或上下文。

### Finding：争议负例与检索支持冲突

#### P1 — Lane A / q080：一般政策问题已有完整条件式答案

位置：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/a/fixture.json:1324-1336`

- 问题：`For north, what is the allowed demo rendering concurrency after October 2027?`
- 原标签：ambiguous；`expected_all=[]`；`forbidden` 包含 r028。
- 证据：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/a/fixture.json:166-169`，r028 明确规定普通任务 **5** 个并行，teaching-live **2** 个。
- 问题询问一般并行政策，并未要求替某个未注明类别的具体任务选择单一数字。回答“普通 5，教学直播 2”无需猜测，完整覆盖问题。
- 最小修正建议：后续修订版将 r028 作为支持记录；若必须保留 ambiguous，则问题应明确指向类别未知的具体任务。本轮不改原标签。

#### P2 — Lane A / q077：具体颜色有歧义，但正确项目政策被列为禁止记录

位置：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/a/fixture.json:1279-1291`

- 问题：`north 项目这批纸模该用什么颜色的签？`
- 原标签：ambiguous；`expected_all=[]`；`forbidden` 包含 r025。
- 证据：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/a/fixture.json:148-151`，r025 同时给出普通批次蓝色、样品批次银色。
- 缺少样品状态，确实不能选定单一颜色；因此 ambiguous 本身有依据。
- 争议在检索层：r025 是已知 north 实体的直接政策依据，支持条件式回答及针对性澄清，不是错误范围近似项。
- 最小修正建议：区分“不能选定单一答案”与“禁止检索支持政策”。敏感性分析单列，不强制翻为正例。

#### P2 — Lane A / q079：缺交付日期，不等于支持记录不明

位置：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/a/fixture.json:1309-1321`

- 问题：`south 的这张练习图稿应该用哪个框版本？`
- 原标签：ambiguous；`expected_all=[]`；`forbidden` 包含 r031。
- 证据：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/a/fixture.json:184-187`，r031 规定 2027-05-10 前交付用 S7，当日起用 S8。
- 缺日期，无法选定单一版本；ambiguous 有依据。但实体及项目已确定，r031 唯一直接提供版本选择规则。
- 最小修正建议：保留答案歧义，同时避免把正确范围的完整政策等同禁止证据；敏感性单列。

### Finding：正例措辞或记录存在欠明确之处

以下 **4 个案例未证明 `expected_all` 引用了错误记录**；争议在问题前提或精确应用条件，不宜机械翻成 no_answer。

#### P2 — Lane A / q017：61 张标签的余数处理未写明

位置：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/a/fixture.json:439-450`

- 问题要求说明 61 张标签如何分组，预期 r002。
- r002 只规定超过 60 张时分成编号的 20 张一捆：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/a/fixture.json:10-13`。
- 61 无法全部组成恰好 20 张的捆。末捆允许不足 20 张、单张另放等处理未明示。
- 最小修正建议：未来明确“每捆最多 20 张，末捆可不足”，或改问不涉及余数的数量。r002 仍是相关支持记录。

#### P2 — Lane B / q025：“long”不能确定超过 80 字

位置：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/b/fixture.json:526-537`

- 问题以 `a long Chinese label` 为前提询问额外审核者，理由却引用超过 80 个汉字。
- r014 的硬条件为“超过80个汉字”，另有改写署名行的独立触发条件：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/b/fixture.json:82-85`。
- “long”没有数值边界。陆汀作为额外审核者有依据，但该标签必然触发额外审核并未被精确确定。
- 最小修正建议：问题明确“超过 80 个汉字”。保留 r014。

#### P2 — Lane B / q027、q038：说明牌的第二译员审核前提不够明确

位置：

- `/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/b/fixture.json:552-563`
- `/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/b/fixture.json:700-712`

证据：`/tmp/chmemx-audit-20261117-iOO3MD/phase4/authors/b/fixture.json:100-103`

- r017 明确要求 **visitor leaflets** 由第二译员审核。
- 对 **bilingual exhibit captions**，明确规定 Tavi 核对两种语言面板的物件编号。
- q027 的 `Besides a second linguist`、q038 的“在第二译员审核外”，均把说明牌也须第二译员审核作为既定前提。
- `also checks` 可以暗示额外审核，但前句的明确适用对象仅是 leaflets；说明牌是否继承第二译员要求存在文本解释空间。
- Tavi 与物件编号核对本身有直接支持，不能据此判整个正例无支持。
- 最小修正建议：删去问题中的第二译员前提；未来若确有共同要求，再明确写入记录。

### 争议清单与敏感性建议

共列 **7 个唯一案例**：

- 强争议负例：**A/q080**。
- 答案歧义与支持记录禁止混用：**A/q077、A/q079**。
- 措辞、前提或应用细节欠明确：**A/q017、B/q025、B/q027、B/q038**。

建议父代理保留全部原标签，另报：

1. 原始 160 案例结果。
2. 排除 A/q080 后的 159 案例敏感性。
3. 排除 A/q077、A/q079、A/q080 后的 157 案例敏感性。
4. 如需宽口径文本质量敏感性，再单列排除全部 7 项后的 153 案例结果。

这些集合仅来自结果前文本审阅，不是要求检索系统必须通过，也不是授权修改标签。

### Fixed

无。未编辑 fixture 或其他文件。

### 验证与限制

- 已实际读取指定 `pua/SKILL.md` 与 `methodology-tesla.md`。
- 业务资料仅读 author-spec 与两个指定 fixture。
- 未读检索实现、planner、旧结果、共享记忆；未调用检索、网页或 MCP。
- 验证方式：完整文件分段阅读、逐案人工对照、限定文件定位搜索。
- 未运行程序、测试或机器校验；无进程退出码。不声称验证 JSON 解析、哈希、冻结文件或 questions-only 派生物。
- 未验证实际检索排序、过滤及评分行为；“禁止正确政策记录”的实际扣分影响须由父代理单独确认。
- 可用工具未提供模型路由证明；未自行切换模型或强度。
- 本任务观察到真实失败次数：0。无需失败升级报告。
- 无需补充权限即可完成此次文本审阅。

### Merge verdict

**OK with notes**：可继续保留原标签的独立评估；并列报告争议敏感性。不能将原始 gold 宣称为全部无争议。