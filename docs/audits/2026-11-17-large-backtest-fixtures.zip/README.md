# Frozen synthetic retrieval benchmark

64 fictional records; 160 distinct EN/ZH questions; 9 configurations; 1,440 executions.
Original labels and independent plans retained, including known pre-result disputes.
No real-memory bodies, old private queries, credentials or model weights included.

## Replay

Install this exact CHmemX source revision with its existing semantic dependencies.
Supply an operator-owned, hash-locked local model directory; no downloads are performed.
Set CHMEMX_REPO to that source checkout and CHMEMX_MODEL_DIR to the model directory.
Extract into a new disposable directory. Run:

    python -B -m unittest discover -s . -p test_metrics.py
    python -B run.py --validate-only
    python -B run.py

Source files must match source-freeze.json. New audit output files do not affect that check.
Runner creates only a disposable sandbox under the extraction directory, including test Git
commits and synthetic approval receipts. Never point sandbox at a real memory store.
The full original run used local fixed paths; this bundled runner differs only in environment-
based source/model path configuration and importing os. Its validate-only path was checked;
the 1,440 reported executions come from the original frozen local harness, not a second run.
New Git record IDs, absolute paths and timestamps can change index hashes on replay.
Metrics/labels/ranking code remain unchanged. Plan-generation and model-download time excluded.

Primary: hybrid planned K=3. Completeness allows non-forbidden extra records; exact-set does not.
Ambiguity handling and no-answer rejection must be reported separately.
