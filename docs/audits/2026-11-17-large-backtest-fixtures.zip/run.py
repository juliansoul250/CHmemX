"""Frozen, disposable, source-checked large retrieval experiment. No production tuning."""
import argparse
import os
from collections import Counter, defaultdict
import copy
import hashlib
import json
from pathlib import Path
import random
import subprocess
import time
from unittest.mock import patch

from chmemx import query_plan
from chmemx.service import Service
from chmemx.scripts import retrieval_v3 as search
from metrics import outcome, summarize, cluster_bootstrap

ROOT = Path(__file__).resolve().parent
REPO = Path(os.environ['CHMEMX_REPO']).resolve()
MODEL = Path(os.environ['CHMEMX_MODEL_DIR']).resolve()
CATEGORIES = {'direct':16,'paraphrase':16,'multi_intent':16,'conditional':8,'no_answer':16,'ambiguous':8}


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def git(path, *args):
    return subprocess.check_output(['git','-C',str(path),*args], text=True).strip()


def verify_sources():
    frozen=load(ROOT/'source-freeze.json')
    changed=[name for name,digest in frozen.items() if sha(REPO/name)!=digest]
    if changed:
        raise AssertionError(f'Pre-existing project files changed: {changed}')
    return len(frozen)


def inputs():
    records=[]; cases=[]; plans={}; files={}; plan_errors={}
    for lane in ('a','b'):
        base=ROOT/'authors'/lane
        fixture=load(base/'fixture.json'); questions=load(base/'questions-only.json')
        planned=load(ROOT/'planners'/lane/'plans.json')
        assert len(fixture['records'])==32 and len(fixture['cases'])==80
        assert Counter(c['category'] for c in fixture['cases'])==CATEGORIES
        assert Counter(r['project'] for r in fixture['records'])=={None:24,'north':4,'south':4}
        assert len({c['query'].strip().casefold() for c in fixture['cases']})==80
        assert len({r['id'] for r in fixture['records']})==32
        assert len({c['id'] for c in fixture['cases']})==80
        assert all(sum(c['language']==language for c in fixture['cases'])>=32 for language in ('en','zh'))
        assert sum(c['project'] is not None for c in fixture['cases'])>=16
        assert questions==[dict(id=c['id'],query=c['query'],project=c['project']) for c in fixture['cases']]
        assert [p['id'] for p in planned]==[q['id'] for q in questions]
        known={r['id']:r for r in fixture['records']}
        for record in fixture['records']:
            assert record['project'] in (None,'north','south')
            assert all(isinstance(record[k],str) and record[k].strip() for k in ('id','body','title'))
            records.append({**record,'lane':lane,'key':f'benchmark.{lane}.{record["id"]}'})
        for case, interpreted in zip(fixture['cases'], planned):
            assert set(case['expected_all']+case['forbidden'])<=set(known)
            assert not set(case['expected_all']) & set(case['forbidden'])
            assert bool(case['expected_all']) == (case['category'] not in ('no_answer','ambiguous'))
            assert all(known[key]['project'] in (None,case['project']) for key in case['expected_all'])
            assert case['reason'].strip() and case['cluster'].strip()
            assert interpreted['plan']['query']==case['query']
            identifier=f'{lane}-{case["id"]}'
            try:
                query_plan.validate(case['query'], interpreted['plan'], association_limit=0)
            except (ValueError,TypeError,KeyError) as exc:
                plan_errors[identifier]=str(exc)
            plans[identifier]=interpreted['plan']
            cases.append({**case,'id':identifier,'lane':lane,'cluster':f'{lane}:{case["cluster"]}',
                          'expected_all':[f'benchmark.{lane}.{key}' for key in case['expected_all']],
                          'forbidden':[f'benchmark.{lane}.{key}' for key in case['forbidden']]})
        for path in (base/'fixture.json',base/'questions-only.json',base/'freeze.json',ROOT/'planners'/lane/'plans.json'):
            files[str(path.relative_to(ROOT))]=sha(path)
    assert len({(c['project'],c['query'].strip().casefold()) for c in cases})==160
    return records,cases,plans,files,plan_errors


def prepare(records):
    project_dirs={}
    for name in ('north','south','outside'):
        directory=ROOT/'sandbox'/name; directory.mkdir(parents=True,exist_ok=True)
        project_dirs[name]=directory
        if name!='outside' and not (directory/'.git').exists():
            git(directory,'init','-q');git(directory,'config','user.name','Synthetic benchmark')
            git(directory,'config','user.email','benchmark@example.invalid')
            (directory/'source.md').write_text('\n\n'.join(r['body'] for r in records if r['project']==name))
            git(directory,'add','source.md');git(directory,'commit','-qm','Freeze fictional source facts')
    store=ROOT/'sandbox/store'
    service=Service(store,project_dirs['north'],'phase4-fixture',MODEL)
    if not store.exists():
        service.initialize('project-north','team')
        service.runtime.register_project(project_dirs['south'],'project-south','south',confirmed=True)
        services={name:Service(store,path,'phase4-fixture',MODEL) for name,path in project_dirs.items()}
        candidate_ids=[]
        for row in records:
            scoped=services[row['project'] or 'north'];scope='project' if row['project'] else 'global'
            source=scoped.source({'path':'source.md'} if row['project'] else {'quote':row['body']},scope)
            proposed=scoped.runtime.propose({'scope':scope,'class':'preference','key':row['key'],
                'body':row['body'],'source':source,'submitted_by_agent':'phase4-fixture',
                'nodes':[{'id':f'node-{row["lane"]}-{row["id"]}','title':row['title'],
                          'keywords':[row['title']],'aliases':[],'related_node_ids':[]}]},scoped.cwd)
            candidate_ids.append(proposed['candidate_id'])
        batch=service.runtime.create_batch(candidate_ids); review=service.runtime.review(batch['batch_id'])
        service.runtime.approve(batch['batch_id'],batch['batch_digest'],review['required_confirmation'],
                                committing_agent='phase4-fixture')
        service.rebuild()
    index=load(service.index_path)
    assert len(index['records'])==64
    return index,project_dirs,service.index_path


def run():
    source_count=verify_sources()
    records,cases,plans,hashes,plan_errors=inputs()
    audit=ROOT/'gold-audit-original.md'
    assert audit.exists(), 'Pre-result independent gold review must be captured before retrieval'
    hashes['gold-audit-original.md']=sha(audit)
    hashes['disputed-labels.json']=sha(ROOT/'disputed-labels.json')
    hashes['model-lock.json']=sha(MODEL/'model-lock.json')
    hashes['source-freeze.json']=sha(ROOT/'source-freeze.json')
    hashes['run.py']=sha(Path(__file__))
    hashes['metrics.py']=sha(ROOT/'metrics.py')
    hashes['protocol']=sha(REPO/'docs/audits/2026-11-17-large-backtest-protocol.md')
    manifest=ROOT/'execution-freeze.json'
    if manifest.exists():
        assert load(manifest)['hashes']==hashes, 'Frozen inputs changed; do not rerun silently'
    else:
        save(manifest,{'hashes':hashes,'existing_files_frozen':source_count,'record_count':64,
                       'case_count':160,'plan_errors':plan_errors,'created_at_ns':time.time_ns()})
    index,project_dirs,index_path=prepare(records)
    index_sha256=sha(index_path)
    readers={'hybrid':search.Retriever(index)}
    lexical=copy.deepcopy(index)
    lexical['hybrid'].update(model_directory=None,model_lock=None,chunks=[])
    lexical['vectorizer']['semantic_embedding']=False
    lexical.pop('index_digest');lexical['index_digest']=search.digest(lexical)
    readers['lexical']=search.Retriever(lexical)
    configurations=[('hybrid',method,k) for method in ('literal','planned') for k in (1,3,5)]
    configurations += [('lexical',method,3) for method in ('literal','planned')]
    configurations += [('hybrid','single',3)]
    jobs=[(config,case) for config in configurations for case in cases]
    random.Random(20261117).shuffle(jobs)
    results=[]
    for number,((backend,method,k),case) in enumerate(jobs,1):
        reader=readers[backend];cwd=project_dirs[case['project'] or 'outside']
        plan=plans[case['id']] if method=='planned' else {'version':1,'query':case['query'],
             'decision':'search','goal':case['query'],'entities':[],'constraints':[],'facets':[]}
        elapsed=time.perf_counter();error=None;read_ids=[]
        try:
            with patch.object(reader,'read',wraps=reader.read) as reads:
                result=reader.recall(case['query'],cwd,k,0,**({} if method=='literal' else {'query_plan':plan}))
            read_ids=[c.args[0] for c in reads.call_args_list]
            returned=[entry['key'] for entry in result['entries']]
            associations=[entry['key'] for entry in result['associations']]
            status=result.get('status','RESULTS')
        except (ValueError,TypeError,KeyError) as exc:
            result={};returned=[];associations=[];status='ERROR';error=f'{type(exc).__name__}: {exc}'
        measured=outcome(case,returned,status,associations)
        allowed=reader.allowed(case['query'],reader.project(cwd))
        violations=[entry['key'] for entry in result.get('entries',[]) if entry.get('project_id') not in allowed]
        results.append({**measured,'id':case['id'],'lane':case['lane'],'cluster':case['cluster'],
            'category':case['category'],'language':case['language'],'project':case['project'],
            'backend':backend,'method':method,'k':k,'elapsed_ms':(time.perf_counter()-elapsed)*1000,
            'body_reads':len(read_ids),'unique_body_reads':len(set(read_ids)),
            'response_bytes':len(json.dumps(result,ensure_ascii=False).encode()),
            'original_scope_outside_keys':violations,'error_message':error,
            'understanding':result.get('understanding'),'retrieval':result.get('retrieval')})
        if number%160==0:
            print(f'completed {number}/{len(jobs)}',flush=True)
            save(ROOT/'results-checkpoint.json',results)
    verify_sources()
    assert sha(index_path)==index_sha256, 'Index file changed during evaluation'
    assert git(Path(index['memory_graph_store']),'rev-parse','HEAD')==index['memory_graph_head']
    save(ROOT/'results.json',{'index_sha256':sha(index_path),'store_head':index['memory_graph_head'],
           'source_checks':True,'records':64,'questions':160,'query_executions':len(results),
           'manifest_sha256':sha(manifest),'cases':results})
    groups=defaultdict(list)
    for row in results:
        groups[f'{row["backend"]}_{row["method"]}_k{row["k"]}'].append(row)
    summaries={key:summarize(value) for key,value in groups.items()}
    for method in ('literal','planned','single'):
        key=f'hybrid_{method}_k3';rows=groups[key]
        summaries[key]['cluster_complete_support_ci95']=cluster_bootstrap(rows,'complete_support')
        summaries[key]['cluster_exact_match_ci95']=cluster_bootstrap(rows,'exact_match')
        summaries[key]['breakdowns']={field:{str(val):summarize([r for r in rows if r[field]==val])
            for val in sorted({r[field] for r in rows},key=str)}
            for field in ('lane','language','category','project')}
    paired=[]
    before={r['id']:r for r in groups['hybrid_literal_k3']}
    for row in groups['hybrid_planned_k3']:
        paired.append({'cluster':row['cluster'],'complete_delta':int(row['complete_support'])-int(before[row['id']]['complete_support']),
                       'exact_delta':int(row['exact_match'])-int(before[row['id']]['exact_match'])})
    summary={'new_unique_questions':160,'query_executions':len(results),'records':64,
             'topic_clusters':len({c['cluster'] for c in cases}),'configurations':summaries,
             'paired_cluster_delta_ci95':{'complete_support':cluster_bootstrap(paired,'complete_delta'),
                                           'exact_match':cluster_bootstrap(paired,'exact_delta')},
             'planned_errors':plan_errors,'duplicate_body_reads':sum(r['body_reads']-r['unique_body_reads'] for r in results),
             'max_body_reads':max(r['body_reads'] for r in results),
             'scope_outside_cases':{method:sum(bool(r['original_scope_outside_keys']) for r in results if r['method']==method)
                                     for method in ('literal','planned','single')},
             'input_hashes':hashes,'index_sha256':sha(index_path),'results_sha256':sha(ROOT/'results.json'),
             'limitations':['Synthetic Agent-authored data, not production user sampling.',
                            'Candidate retrieval only; no generated-answer evaluation.',
                            '160 questions share64 facts and topic clusters; 1440 executions are not independent samples.',
                            'Plan-generation time excluded; latency diagnostic only.']}
    save(ROOT/'summary.json',summary)
    print(json.dumps({key:{metric:value[metric] for metric in ('complete_support_rate','exact_match_rate','mean_precision','mean_recall','correct_empty_rate')}
                      for key,value in summaries.items()},ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--validate-only',action='store_true');args=parser.parse_args()
    if args.validate_only:
        records,cases,plans,hashes,errors=inputs();print(json.dumps({'records':len(records),'cases':len(cases),'plan_errors':errors},indent=2))
    else:
        run()
