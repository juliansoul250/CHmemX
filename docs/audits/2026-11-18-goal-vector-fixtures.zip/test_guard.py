import unittest
from types import SimpleNamespace
from unittest.mock import Mock
import numpy as np
from experiment import guarded_order, choose


class GuardTests(unittest.TestCase):
    def setUp(self):
        self.r=SimpleNamespace(encoder=SimpleNamespace(np=np,encode=Mock(return_value=[[1,0]]),tokenizer=SimpleNamespace(encode=Mock(return_value=SimpleNamespace(overflowing=[])))),index={'hybrid':{'chunks':[{'record_id':'a','vector':[.2,0]},{'record_id':'b','vector':[.8,0]},{'record_id':'a','vector':[.6,0]},{'record_id':'foreign','vector':[1,0]}]}},records={'a':{'key':'topic.alpha'},'b':{'key':'topic.beta'}},_dense_matrix=None)
        self.rank={'order':['a','b']};self.plan={'query':'a question','goal':'requested fact','facets':[],'decision':'search'}

    def test_max_body_score_filter_no_new_ids_or_reorder(self):
        self.assertEqual(guarded_order(self.r,self.rank,self.plan,.58),['a','b'])
        self.assertEqual(guarded_order(self.r,self.rank,self.plan,.68),['b'])
        self.assertEqual(self.rank['order'],['a','b'])

    def test_preserve_explicit_original_key_not_goal(self):
        plan={**self.plan,'query':'inspect topic.alpha','goal':'topic.beta'}
        self.assertEqual(guarded_order(self.r,self.rank,plan,.9),['a'])

    def test_skip_facets_and_long_goals(self):
        self.assertEqual(guarded_order(self.r,self.rank,{**self.plan,'facets':[{'id':'one'}]},.95),['a','b'])
        self.r.encoder.tokenizer.encode.return_value.overflowing=[1]
        self.assertEqual(guarded_order(self.r,self.rank,self.plan,.95),['a','b'])
        self.r.encoder.encode.assert_not_called()

    def test_positive_regression_cannot_win_despite_more_empty_negatives(self):
        old={'complete':8,'exact':7,'positive':6,'multi':3,'false_returns':4,'errors':0}
        configs={'base':old,'low':{**old,'complete':10,'positive':5,'false_returns':1},'mid':{**old,'complete':9,'false_returns':3},'high':{**old,'complete':9,'false_returns':3}}
        self.assertEqual(choose(configs),('mid',True))
        del configs['mid'],configs['high'];self.assertEqual(choose(configs),('low',False))

if __name__=='__main__':unittest.main()
