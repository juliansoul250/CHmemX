"""Predeclared candidate-retrieval metrics; no generation accuracy claims."""
from collections import defaultdict
import math
import random
import statistics


def wilson(success, count):
    if not count:
        return None
    z = 1.959963984540054
    p = success / count
    denominator = 1 + z*z/count
    centre = (p + z*z/(2*count)) / denominator
    radius = z*math.sqrt(p*(1-p)/count + z*z/(4*count*count))/denominator
    return [max(0., centre-radius), min(1., centre+radius)]


def cluster_bootstrap(rows, field, samples=5000):
    groups = defaultdict(list)
    for row in rows:
        if row.get(field) is not None:
            groups[row['cluster']].append(float(row[field]))
    if not groups:
        return None
    values = list(groups.values())
    rng = random.Random(20261117)
    trials = []
    for _ in range(samples):
        selected = [item for group in rng.choices(values, k=len(values)) for item in group]
        trials.append(statistics.mean(selected))
    trials.sort()
    return [trials[int(.025*(samples-1))], trials[math.ceil(.975*(samples-1))]]


def outcome(case, returned, status, associations=()):
    expected = set(case['expected_all'])
    observed = set(returned)
    forbidden = set(case.get('forbidden', [])) & (observed | set(associations))
    error = status == 'ERROR'
    positive = bool(expected)
    hits = expected & observed
    empty = not returned and not associations and not error
    return {
        'positive': positive, 'error': error,
        'complete_support': not error and not forbidden and (expected <= observed if positive else empty),
        'exact_match': not error and not forbidden and observed == expected and (positive or not associations),
        'hit_at_one': bool(returned and returned[0] in expected) if positive else None,
        'hit_at_k': bool(hits) if positive else None,
        'rr': next((1/(i+1) for i, key in enumerate(returned) if key in expected), 0.) if positive else None,
        'recall': len(hits)/len(expected) if positive else None,
        'precision': len(hits)/len(returned) if positive and returned else (0. if positive else None),
        'correct_empty': empty if not positive else None,
        'negative_false_return': bool(returned or associations) if not positive else None,
        'forbidden_return_count': len(forbidden), 'missing': sorted(expected-observed),
        'extra': sorted(observed-expected), 'returned': returned, 'status': status,
    }


def summarize(rows):
    positive = [r for r in rows if r['positive']]
    negative = [r for r in rows if not r['positive']]
    def rate(selected, field):
        return statistics.mean(float(r[field]) for r in selected) if selected else None
    complete = sum(r['complete_support'] for r in rows)
    exact = sum(r['exact_match'] for r in rows)
    return {
        'count': len(rows), 'positive_count': len(positive), 'negative_count': len(negative),
        'errors': sum(r['error'] for r in rows),
        'complete_support_count': complete, 'complete_support_rate': rate(rows, 'complete_support'),
        'complete_support_wilson95': wilson(complete, len(rows)),
        'exact_match_count': exact, 'exact_match_rate': rate(rows, 'exact_match'),
        'exact_match_wilson95': wilson(exact, len(rows)),
        'positive_complete_support': rate(positive, 'complete_support'),
        'hit_at_one': rate(positive, 'hit_at_one'), 'hit_at_k': rate(positive, 'hit_at_k'),
        'mrr': rate(positive, 'rr'), 'mean_recall': rate(positive, 'recall'),
        'mean_precision': rate(positive, 'precision'),
        'correct_empty_rate': rate(negative, 'correct_empty'),
        'correct_empty_wilson95': wilson(sum(bool(r['correct_empty']) for r in negative),len(negative)),
        'negative_false_return_rate': rate(negative, 'negative_false_return'),
        'forbidden_return_cases': sum(r['forbidden_return_count'] > 0 for r in rows),
    }
