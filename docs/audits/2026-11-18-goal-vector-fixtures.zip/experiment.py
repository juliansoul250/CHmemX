"""Isolated goal-vector experiment. No candidate output can widen scope or read extra bodies."""
import argparse
from collections import Counter
from contextlib import nullcontext
import hashlib
import json
from pathlib import Path
import random
import statistics
import subprocess
import time
from unittest.mock import patch

from chmemx import query_plan
from chmemx.scripts import retrieval_v3 as search
from chmemx.service import Service
from metrics import outcome, summarize, cluster_bootstrap

ROOT=Path(__file__).resolve().parent
MODES=('low','mid','high')
CATEGORIES={'direct':12,'paraphrase':8,'multi_intent':8,'conditional':4,'no_answer':16}


def read(path):return json.loads(path.read_text())

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def freeze(path,obj):
    text=json.dumps(obj,ensure_ascii=False,indent=2)+'\n'
    with path.open('x') as stream:stream.write(text)


def guarded_order(reader,ranking,plan,threshold):
    order=ranking['order']; encoder=reader.encoder
    chunks=reader.index['hybrid']['chunks']
    if (not order or not encoder or not chunks or plan['decision']!='search' or plan['facets']
            or ranking.get('dense_window_exceeded') or encoder.tokenizer.encode(plan['goal']).overflowing):
        return order
    vector=encoder.np.asarray(encoder.encode([plan['goal']])[0]);matrix=reader._dense_matrix
    if matrix is None:matrix=encoder.np.asarray([c['vector'] for c in chunks])
    wanted=set(order); retained=set();text=search.lexical.normalize_text(plan['query'])
    for c,score in zip(chunks,matrix @ vector):
        if c['record_id'] in wanted and score>=threshold:retained.add(c['record_id'])
    return [rid for rid in order if rid in retained or reader.records[rid]['key'] in text]


def qualifies(row,base):
    return (not row['errors'] and row['complete']>base['complete'] and row['false_returns']<base['false_returns']
            and all(row[field]>=base[field] for field in ('positive','multi','exact')))


def choose(configs):
    options=[m for m in MODES if m in configs]
    passing=[m for m in options if qualifies(configs[m],configs['base'])]
    return max(passing or options,key=lambda m:(configs[m]['complete'],configs[m]['exact'])),bool(passing)


def inputs(split):
    f=read(ROOT/split/'fixture.json');questions=read(ROOT/split/'questions.json');ps=read(ROOT/('plan-'+split)/'plans.json')
    rows=f['cases'];records=f['records'];rs={r['id']:r for r in records}
    assert len(rs)==len(records)==16 and len({r['id'] for r in rows})==len(rows)==48
    assert Counter(c['language'] for c in rows)=={'zh':24,'en':24}
    assert Counter(c['category'] for c in rows)==CATEGORIES
    assert len({r['query'].strip().casefold() for r in rows})==48
    assert questions==[{k:c[k] for k in ('id','query')} for c in rows]
    assert [p['id'] for p in ps]==[c['id'] for c in rows]
    for c,p in zip(rows,ps):
        assert set(c['expected_all']+c['forbidden'])<=set(rs) and not set(c['expected_all'])&set(c['forbidden'])
        assert bool(c['expected_all'])==(c['category']!='no_answer')
        assert c['category']!='multi_intent' or len(set(c['expected_all'])) in (2,3)
        query_plan.validate(c['query'],p['plan'],limit=3,association_limit=0)
    return records,rows,{p['id']:p['plan'] for p in ps}


def sandbox(split,records,model):
    root=ROOT/'sandbox'/split;project=root/'project';project.mkdir(parents=True,exist_ok=True)
    if not (project/'.git').is_dir():subprocess.run(['git','init','-q',str(project)],check=True)
    store=root/'store';svc=Service(store,project,'goal-vector-fixture',model)
    keys={r['id']:'bench.'+split+'.'+r['id'] for r in records};source_hash=sha(ROOT/split/'fixture.json')
    if not store.exists():
        svc.initialize('project-fixture','team');ids=[]
        for r in records:
            c=svc.runtime.propose({'scope':'global','class':'preference','key':keys[r['id']],'body':r['body'],
               'source':svc.source({'quote':r['body']},'global'),'submitted_by_agent':'goal-vector-fixture',
               'nodes':[{'id':'node-'+r['id'],'title':r['title'],'keywords':[r['title']],'aliases':[],'related_node_ids':[]}]},project)
            ids.append(c['candidate_id'])
        batch=svc.runtime.create_batch(ids);review=svc.runtime.review(batch['batch_id'])
        svc.runtime.approve(batch['batch_id'],batch['batch_digest'],review['required_confirmation'],committing_agent='goal-vector-fixture')
        svc.rebuild();freeze(root/'binding.json',{'fixture':source_hash,'index':sha(svc.index_path)})
    assert read(root/'binding.json')=={'fixture':source_hash,'index':sha(svc.index_path)}
    return svc._reader(),project,keys


def evaluate(reader,rows,plans,keys,cwd_for,modes):
    inverse={v:k for k,v in keys.items()};h=reader.index['hybrid'];cutoffs=dict(zip(MODES,(h['dense_minimum']+s*h['dense_window'] for s in (-1,0,1))))
    jobs=[(c,m) for c in rows for m in modes];random.Random(20261118).shuffle(jobs);data=[]
    for c,m in jobs:
        plan=plans[c['id']];cwd=cwd_for(c)
        rank=reader._rank_pointers
        def guarded(*args,**kwargs):
            res=rank(*args,**kwargs);return {**res,'order':guarded_order(reader,res,plan,cutoffs[m])}
        hook=nullcontext() if m=='base' else patch.object(reader,'_rank_pointers',side_effect=guarded)
        start=time.perf_counter();error=None;reads=0
        try:
            with hook, patch.object(reader,'read',wraps=reader.read) as tracked:
                response=reader.recall(c['query'],cwd,3,0,query_plan=plan);reads=tracked.call_count
            returned=[inverse[e['key']] for e in response['entries']];status=response['status']
            assert not response['associations'] and reads<=20
            assert all(e['project_id'] in reader.allowed(c['query'],reader.project(cwd)) for e in response['entries'])
        except (ValueError,TypeError,KeyError) as exc:
            error=str(exc);returned=[];status='ERROR'
        data.append({**outcome(c,returned,status),'id':c['id'],'cluster':c['cluster'],'category':c['category'],
                     'language':c['language'],'mode':m,'ms':(time.perf_counter()-start)*1000,'reads':reads,'error_detail':error})
    return data


def report(rows):
    modes={}
    for m in ('base',*MODES):
        data=[r for r in rows if r['mode']==m]
        if not data:continue
        modes[m]={'complete':sum(r['complete_support'] for r in data),'positive':sum(r['positive'] and r['complete_support'] for r in data),
                  'multi':sum(r['category']=='multi_intent' and r['complete_support'] for r in data),'exact':sum(r['exact_match'] for r in data),
                  'false_returns':sum(r['category']=='no_answer' and bool(r['negative_false_return']) for r in data),
                  'errors':sum(r['error'] for r in data),'mean_reads':statistics.mean(r['reads'] for r in data),
                  'median_ms':statistics.median(r['ms'] for r in data),'all':summarize(data),
                  'language':{l:summarize([r for r in data if r['language']==l]) for l in ('en','zh')}}
    base={r['id']:r for r in rows if r['mode']=='base'}
    for m in modes:
        if m=='base':continue
        pairs=[{**r,'delta':int(r['complete_support'])-int(base[r['id']]['complete_support'])} for r in rows if r['mode']==m]
        modes[m]['paired']={'gains':sum(r['delta']>0 for r in pairs),'losses':sum(r['delta']<0 for r in pairs),
                            'topic_bootstrap_95':cluster_bootstrap(pairs,'delta')}
    return modes


def bindings(model):
    paths=[ROOT/s/f for s in ('dev','holdout') for f in ('fixture.json','questions.json')]+[ROOT/('plan-'+s)/'plans.json' for s in ('dev','holdout')]
    return {**{str(p.relative_to(ROOT)):sha(p) for p in paths},'model_lock':sha(model/'model-lock.json'),
            'harness':sha(Path(__file__)),'metrics':sha(ROOT/'metrics.py'),'ranker':sha(Path(search.__file__)),
            'sparse_scorer':sha(Path(search.lexical.__file__)),'protocol':sha(ROOT/'protocol.md')}


def main():
    arg=argparse.ArgumentParser();arg.add_argument('split',choices=['dev','holdout']);arg.add_argument('--model',type=Path,required=True);args=arg.parse_args()
    model=args.model.resolve();split=args.split;lock=ROOT/'decision.json';binding=bindings(model)
    if split=='holdout':
        selection=read(lock);assert binding==selection['bindings'];modes=('base',selection['diagnostic_candidate'])
    else:
        assert not lock.exists();modes=('base',*MODES)
    records,rows,plans=inputs(split);reader,cwd,keys=sandbox(split,records,model)
    data=evaluate(reader,rows,plans,keys,lambda c:cwd,modes);scores=report(data)
    freeze(ROOT/(split+'-results.json'),data);freeze(ROOT/(split+'-metrics.json'),scores)
    if split=='dev':
        best,passed=choose(scores);freeze(lock,{'bindings':binding,'diagnostic_candidate':best,'development_gate_passed':passed,'dev_results':sha(ROOT/'dev-results.json')})
    print(split,json.dumps({k:{f:v[f] for f in ('complete','positive','multi','false_returns','exact','errors')} for k,v in scores.items()}),flush=True)

if __name__=='__main__':main()
