# Goal vector / sparse scorer experiments

Synthetic records and question-only plans, frozen before scoring. No model weights, canonical data, real queries or access tokens in this archive. `evidence/` contains original input hashes, paired cases, metrics and timing samples. Original results stay immutable; run experiment in a new disposable directory. Product checkout must match the retrieval implementation identified in `evidence/decision.json`. Python environment: install this checkout with semantic extras and supply its previously provisioned, pinned local ONNX model directory. No automatic model download.

```sh
python -m unittest -v test_guard test_metrics
python experiment.py dev --model /absolute/path/to/local-model
python experiment.py holdout --model /absolute/path/to/local-model
```

The first run creates an isolated Git memory store, records candidate selection in a new `decision.json` and will not overwrite it. Holdout verifies the decision's input and code hashes. `sandbox/` is synthetic. Compare predictions (`returned`, `status`, `complete_support`) by `(id, mode)`, not run time or temporary Git IDs. `evidence/regression-*.json` refer to the separately published 160-question 2026-11-17 dataset. For a scorer microbenchmark, `sparse_benchmark.py --before <previous-vector_memory.py> --indexes <index.json> [...] --output <new.json>` expects compatible disposable indexes. It checks complete result equality, then times 56 alternating pairs per index. Full orchestration/model planning latency and production traffic are not measured. The goal filter is diagnostic only: not part of runtime.
