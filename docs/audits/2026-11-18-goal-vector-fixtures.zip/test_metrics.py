import unittest
from metrics import outcome, summarize, wilson, cluster_bootstrap

class MetricsTest(unittest.TestCase):
    def test_positive_miss_counts_in_denominator(self):
        rows=[outcome({'expected_all':['a'],'forbidden':[]},['a'],'OK'),outcome({'expected_all':['b'],'forbidden':[]},[],'OK')]
        s=summarize(rows)
        self.assertEqual(s['positive_count'],2)
        self.assertEqual(s['mean_precision'],.5)
        self.assertEqual(s['mean_recall'],.5)
    def test_extra_result_is_not_exact_match(self):
        r=outcome({'expected_all':['a'],'forbidden':[]},['a','x'],'OK')
        self.assertTrue(r['complete_support']);self.assertFalse(r['exact_match']);self.assertEqual(r['precision'],.5)
    def test_error_not_correct_abstention(self):
        r=outcome({'expected_all':[],'forbidden':[]},[],'ERROR')
        self.assertFalse(r['complete_support']);self.assertFalse(r['correct_empty'])
    def test_partial_multifact_not_complete(self):
        r=outcome({'expected_all':['a','b'],'forbidden':[]},['b'],'OK')
        self.assertEqual(r['recall'],.5);self.assertFalse(r['complete_support']);self.assertEqual(r['rr'],1)
    def test_forbidden_blocks_complete_even_if_gold_found(self):
        r=outcome({'expected_all':['a'],'forbidden':['x']},['a','x'],'OK')
        self.assertFalse(r['complete_support']);self.assertEqual(r['forbidden_return_count'],1)
    def test_rank_and_empty_denominators(self):
        r=outcome({'expected_all':['a'],'forbidden':[]},['x','a'],'OK')
        self.assertEqual(r['rr'],.5);self.assertFalse(r['hit_at_one'])
        self.assertEqual(summarize([])['count'],0)
        self.assertIsNone(summarize([])['correct_empty_rate'])
    def test_interval_and_clustering(self):
        self.assertAlmostEqual(wilson(0,10)[0],0)
        self.assertGreater(wilson(0,10)[1],0)
        self.assertEqual(cluster_bootstrap([{'cluster':'x','score':1}], 'score'),[1.,1.])
if __name__=='__main__': unittest.main()
