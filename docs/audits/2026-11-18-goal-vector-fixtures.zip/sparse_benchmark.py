"""Complete result equality and alternating scorer-only measurements on saved synthetic indexes."""
import argparse
import importlib.util
import json
from pathlib import Path
import statistics
import time
from chmemx.scripts import vector_memory as new


def main():
    p=argparse.ArgumentParser();p.add_argument('--before',type=Path,required=True);p.add_argument('--indexes',type=Path,nargs='+',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    s=importlib.util.spec_from_file_location('chmemx.scripts.pre_change',a.before);old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
    rows=[]
    for path in a.indexes:
        index=json.loads(path.read_text());n=len(index['records']);cwd=path.parent
        queries=[index['records'][0]['key'],index['records'][n//2]['key'],index['records'][-1]['key'],'which colour topic003','topic012 cobalt','蓝色主题','unrelated mango xyz','']
        def bench(f,q):
            t=time.perf_counter_ns();value=f.score_pointers(index,q,n,cwd);return (time.perf_counter_ns()-t)/1e6,value
        for q in queries:assert bench(old,q)[1]==bench(new,q)[1]
        pairs=[]
        for rep in range(8):
            for j,q in enumerate(queries[:-1]):
                first,second=(old,new) if (rep+j)%2==0 else (new,old)
                t1,v1=bench(first,q);t2,v2=bench(second,q);assert v1==v2
                pairs.append([t1,t2] if first is old else [t2,t1])
        rows.append({'records':n,'cells':len(index['cells']),'memberships':sum(len(c['member_record_ids']) for c in index['cells']),'equality_queries':len(queries),'matched_pairs':len(pairs),'old_median_ms':statistics.median(x[0] for x in pairs),'new_median_ms':statistics.median(x[1] for x in pairs),'paired_median_speedup':statistics.median(x/y for x,y in pairs),'pairs_ms':pairs})
    with a.output.open('x') as f:json.dump(rows,f,indent=2)
    print([{k:v for k,v in r.items() if k!='pairs_ms'} for r in rows])
if __name__=='__main__':main()
