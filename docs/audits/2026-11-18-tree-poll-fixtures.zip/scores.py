"""Post-result manipulation check: numeric scores can move without a new Top-3."""
from collections import Counter
from pathlib import Path
from tree_eval import load,sha,write,search,no_navigation


def trace(p,ip,taxonomy,plans,cwd):
    base=load(ip); store=Path(base['memory_graph_store']);t=search.build(store,taxonomy,Path(base['hybrid']['model_directory']),previous=base);rs={m:search.Retriever(t if m=='topic' else base) for m in ('baseline','topic','no_cells','no_navigation')};rs['no_cells'].lexical['cells']=[];_,raw,_=search.lexical.collect_active(store);no_navigation(rs['no_navigation'],{r['id']:r for r in raw});stats=Counter();example={}
    for req in plans:
        plan=req['plan'];qs=[plan['query'],*(s['query'] for s in plan['facets'])];changed={m:False for m in rs};st=Counter();
        for idx,query in enumerate(qs):
            vec={m:search.lexical.score_pointers(r.lexical,query,len(raw),cwd) for m,r in rs.items()};sp={m:{e['id']:e['vector_pointer']['score'] for e in arr['entries']} for m,arr in vec.items()}
            assert all(all(e['vector_pointer']['score_components']['cell']==0 for e in vec[m]['entries']) for m in ('no_cells','no_navigation'));assert all(e['vector_pointer']['score_components']['node']==0 for e in vec['no_navigation']['entries'])
            for m in rs:
                if sp[m]!=sp['baseline']:changed[m]=True;st[m+'_subqueries_changed']+=1
            if req['id']=='q011':
                for m in rs:
                    read=rs[m];a=read._rank_pointers(query,cwd,allowed_projects=read.allowed(plan['query'],read.project(cwd)));example.setdefault(m,[]).append({'query_index':idx,'order':[read.records[r]['key'] for r in a['order'][:3]],'wanted':[{k:round(a[k][rid],6) for k in ('sparse','bm','dense')}|{'key':read.records[rid]['key']} for rid in sorted(a['eligible']) if read.records[rid]['key'] in ('tree.sample.r008','tree.sample.r009')],'dense_max':max(a['dense'].values())})
        stats.update(st);stats['original_or_facet_queries']+=len(qs)
        for m,v in changed.items():stats[m+'_questions_with_some_sparse_delta']+=v
    write(p/'scores.json',{'counts':dict(stats),'q011':example});print('Score controls',stats);print('q011 original', {m:[r[0]['order'],r[0]['wanted']] for m,r in example.items()})
if __name__=='__main__':
    p=Path(__file__).resolve().parent;w=p/'work/new';trace(p,w/'store/.queue/chmemx/index.json',w/'compare/candidate-directory.json',load(p/'planner/plans.json'),w/'project')
