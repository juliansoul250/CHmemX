"""Parent adapter for archived synthetic fixtures; not for a live store."""
import importlib.util
from pathlib import Path
import sys
from tree_eval import compare,gate,load,run_new,sha,write,MODES
from chmemx.scripts import retrieval_v3 as search
P=Path(__file__).resolve().parent;A=P.parent;OLD=A/'phase5';LARGE=A/'phase4';MODEL=A/'private-ranking/model';REPO=Path.cwd();work=P/'work'

def imported(name,file):
    s=importlib.util.spec_from_file_location(name,file);mod=importlib.util.module_from_spec(s);s.loader.exec_module(mod);return mod

def main():
    exp=imported('exp',OLD/'experiment.py');prev=imported('large_suite',LARGE/'run.py');old_groups={};bindings=load(P/'input-freeze.json');assert {k:sha(f) for k,f in {'fixture':P/'author/fixture.json','plans':P/'planner/plans.json','questions':P/'author/questions.json','protocol':REPO/'docs/audits/2026-11-18-tree-poll-protocol.md','model_lock':MODEL/'model-lock.json','round_packet':P/'packet.json','round_harness':P/'poll.py'}.items()}==bindings
    write(P/'execution-freeze.json',{'inputs':bindings,'harness':sha(P/'tree_eval.py'),'runner':sha(Path(__file__)),'metrics':sha(P/'metrics.py'),'scorer':sha(Path(search.lexical.__file__)),'ranker':sha(Path(search.__file__)),'modes':MODES})
    for s in ('dev','holdout'):
        records,cs,ps=exp.inputs(s);p=OLD/'sandbox'/s;ip=p/'store/.queue/chmemx/index.json';assert load(p/'binding.json')=={'fixture':sha(OLD/s/'fixture.json'),'index':sha(ip)};arch={r['id']:r for r in load(OLD/(s+'-results.json')) if r['mode']=='base'};lock=load(OLD/'decision.json')['bindings'];assert all(sha(OLD/local)==lock[local] for local in (s+'/fixture.json',s+'/questions.json','plan-'+s+'/plans.json'))
        old_groups[s]=compare(s,ip,cs,ps,{r['id']:f"bench.{s}.{r['id']}" for r in records},lambda c:p/'project',work/s,arch)
    rs,cs,ps,files,errors=prev.inputs();assert not errors and all(load(LARGE/'execution-freeze.json')['hashes'][k]==v for k,v in files.items());p=LARGE/'sandbox';ip=p/'store/.queue/chmemx/index.json';arch=load(LARGE/'results.json');assert sha(ip)==arch['index_sha256'];original={r['id']:r for r in arch['cases'] if (r['backend'],r['method'],r['k'])==('hybrid','planned',3)}
    old_groups['large']=compare('large',ip,cs,ps,{r['key']:r['key'] for r in rs},lambda c:p/(c['project'] or 'outside'),work/'large',original)
    new=run_new(P/'author/fixture.json',P/'author/questions.json',P/'planner/plans.json',work/'new',MODEL)
    groups={**old_groups,'new':new};decision={'promote_topic':gate(groups),'total_questions':sum(s['baseline']['count'] for s in groups.values()),'configurations':len(MODES),'groups':groups};write(P/'decision.json',decision);print('PROMOTE_TOPIC',decision['promote_topic'],'QUESTIONS',decision['total_questions'],flush=True)
if __name__=='__main__':main()
