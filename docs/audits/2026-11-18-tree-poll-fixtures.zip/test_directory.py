import unittest
from tree_eval import topic_cells, gate, no_navigation
from types import SimpleNamespace
from chmemx.scripts import retrieval_v3 as search


def record(rid, scope=None, key=None):
    return {'id':rid,'key':key or 'example.'+rid,'project_id':scope}

def node(uid,*ids):return {'uid':uid,'record_ids':list(ids),'title':'Label '+uid,'keywords':[uid],'aliases':[]}

class DirectoryTests(unittest.TestCase):
    def test_shared_subsets_only_preserve_residual_aliases_and_stable_ids(self):
        rs=[record(x) for x in 'abcde'];ns=[node('alpha','a','b'),node('duplicate','a','b'),node('whole',*'abcde'),node('single','e'),node('beta','c','d')]
        result=topic_cells(rs,ns); self.assertEqual(result,topic_cells(rs[::-1],ns[::-1])); self.assertEqual([('Label alpha',('example.a','example.b')),('Label beta',('example.c','example.d')),('example',('example.e',))],sorted((c['title'],tuple(c['member_keys'])) for c in result)); self.assertEqual(len({c['id'] for c in result}),3)
        self.assertEqual(next(c for c in result if c['title']=='example')['id'],'cell-'+search.digest([None,'example'])[:20]); self.assertTrue(all(c['scope']=='global' for c in result))

    def test_no_shared_node_and_ambiguous_duplicate_key_keep_prefix(self):
        rs=[record(x) for x in 'abc'];self.assertEqual(len(topic_cells(rs,[node(x,x) for x in 'abc'])),1)
        rs.append(record('d',key='example.a'));self.assertEqual(len(topic_cells(rs,[node('shared','a','b')])),1)

    def test_membership_stays_in_each_project_and_prefix(self):
        rs=[record('a'),record('b'),record('c'),record('p','p',key='example.a'),record('x',key='another.x')];ns=[node('shared','a','b','p','x')]
        cells=topic_cells(rs,ns); shared=next(c for c in cells if c['title']=='Label shared');self.assertEqual(shared['member_keys'],['example.a','example.b']);self.assertEqual([r['id'] for r in rs if search.lexical.cell_matches_record(shared,r)],['a','b']);self.assertEqual(len(cells),4)

    def test_gate_cannot_trade_off_positive_or_regression_for_total(self):
        b=dict(complete=8,positive=5,multi=3,exact=6,false_returns=2,errors=0,scope=0);s={'new':{'baseline':b,'topic':dict(b,complete=9)},'old':{'baseline':b,'topic':b}}
        self.assertTrue(gate(s));s['new']['topic']['positive']=4;self.assertFalse(gate(s));s['new']['topic']['positive']=5;s['old']['topic']=dict(b,multi=2);self.assertFalse(gate(s))

    def test_ablation_leaves_key_body_and_canonical_metadata_intact(self):
        raw=dict(record('a'),node_uids=['u'],hints=['nav-hint'],**{'class':'preference','_body':'true body','_source_locator':'locator'}); n=node('u','a'); n.update(title='blocked title',aliases=['blocked alias']); ref={**raw}; index={'cells':[{'id':'cell'}],'nodes':[n],'records':[dict(raw)],'vectorizer':{'dimensions':128,'feature_weights':[]}}; reader=SimpleNamespace(lexical=index,navigation_terms={'a':{'alias'}},records={'a':dict(raw)})
        no_navigation(reader,{'a':raw});self.assertEqual(raw,ref);self.assertEqual(reader.records['a']['node_uids'],['u']);self.assertEqual(index['nodes'],[]);self.assertEqual(index['cells'],[]);self.assertEqual(reader.navigation_terms['a'],set(search.lexical.text_tokens('example.a')));self.assertEqual(index['records'][0]['node_uids'],[]);self.assertEqual(index['records'][0]['vector'],search.lexical.sparse_vector(search.lexical.record_vector_texts({**raw,'hints':[],'node_uids':[]},{}),128,{}))
