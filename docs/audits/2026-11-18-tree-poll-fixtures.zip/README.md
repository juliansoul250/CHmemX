# CHmemX directory / round-robin evidence — 2026-11-18

All examples are fictional. This is an offline experiment, not an MCP service or an index for real memories. There are 280 different questions (256 archived, 24 new), four paired K=3 configurations, 1,120 recorded configuration runs. 36 agent calls on a subset of the old 48-question development split are a separate test, not 36 new questions. No model weights, live state, Git stores, accounts or API keys are included.

## Measured version and history

Root `evidence/{dev,holdout,large,new}` and `evidence/decision.json` describe the final scorer with canonical-key ordering. `evidence/stability.json` compares two independently imported copies, including original-to-final differences. All post-fix row fields matched across the two copies, not just totals. No new split or label was introduced during diagnosis.

`execution-freeze.json` is the original pre-result binding. `replay-binding.json` pins the final scorer and service. `history/original-freeze.zip` is the unchanged complete first archive with the original 1,120 rows. `history/initial-cold-replay.json` retains five first-rebuild discrepancies, and `history/one-variable-probe.json` isolates the effect of member order before the fix. The auxiliary `evidence/scores.json` comes from the FIRST experiment; it is a manipulation check, not a final-store score table. `original_run.py` is the pre-fix, fixed-index adapter; root `replay.py` is the final fresh-store verifier.

## Inspect without running anything

- `protocol.md`: decision rule frozen before the holdout was run. `execution-freeze.json`: exact fixture/plan/model/code SHA-256 values; `manifest.json`: per-file SHA-256 for this ZIP.
- `author/`, `planner/`: all 12 new records, four explicit shared topics, all 24 questions, frozen expected keys and separately written question-only plans.
- `packet.json`, `{r1,r2,r3}/{requests,hits,evidence}.json`: the original 12 questions and plans, each agent's actual request, returned bodies, verbatim evidence and missing clauses. `evidence/round-results.json` includes the independent parent replay, labels, body-read counts; the per-round statuses are agent judgments of the current round only, not generated answers.
- `evidence/{dev,holdout,large,new}/rows.json`: ordered record keys, missing/extra keys, status and scores for every option and every question. Rows join by `(suite,id,mode)`. Identifiers refer to synthetic records only. `summary.json`, `structure.json`, `candidate-directory.json`: metrics, group sizes and the actual candidate configuration. `evidence/decision.json`: all paired configuration summaries. `evidence/scores.json`: post-result numerical manipulation check on new questions.
- `tree_eval.py`, `metrics.py`, `poll.py`, `original_run.py`: byte-preserved experiment kernels/parent adapter. The original adapter refers to the historical scratch layout; use `replay.py` below for portable execution. `scores.py` is the post-result diagnostic, not used for ranking decisions.

## Replay

Requires Git, an installation of **this audited CHmemX working tree** with the `semantic` extras, and an existing local copy of the matching locked ONNX model (`model-lock.json` SHA-256 is in `execution-freeze.json`). No model downloads. Use Python without `-O`: the experiment includes assertions. Target a **nonexistent** scratch directory; fresh Git repositories and fictional approvals are created there. No commands accept a real store path. These instructions do not authorize deploying or rebuilding anything.

From this extracted directory:

```sh
python -m unittest -v test_directory
# Small independent holdout only: 24 questions x four configurations.
python replay.py --model "$CHMEMX_MODEL_DIR" --work "$NEW_SCRATCH_DIR"
# All 1,120 paired rows plus the 36 recorded agent requests (use another new path).
python replay.py --model "$CHMEMX_MODEL_DIR" --work "$SECOND_NEW_DIR" --audits "$CHMEMX_REPO/docs/audits"
```

The full command reads two SHA-pinned neighboring public archives (`2026-11-17-large-backtest-fixtures.zip` and `2026-11-18-goal-vector-fixtures.zip`) for their original fixture builders and questions, rather than duplicating the historical datasets here. `replay.json` lists every case/configuration difference, including ordered keys and read counts. Store commits, random record IDs, index file bytes and hardware timings need not repeat; these are not the comparison keys. Round replay uses the agents' recorded plans; it does **not** regenerate their reasoning or call a language model. `python poll.py check r1` (similarly `r2`/`r3`) verifies quote substrings without model inference. Substring provenance alone does not verify entailment.

`baseline` uses the prefix directory. `no_cells` removes directory effects only; `no_navigation` also removes explicit node/alias/keyword/hint scoring and navigation matches at fixed baseline IDF (not pure dense-only). `topic` splits by existing shared, approved node membership inside each scoped key prefix. Exact and complete metrics are record-level; only `complete_support` allows extra non-forbidden records on a positive. Negative complete requires empty results, not a plausible topic hit. `false_returns` in the compact summaries counts `no_answer` only; the large archive also includes ambiguous cases.
