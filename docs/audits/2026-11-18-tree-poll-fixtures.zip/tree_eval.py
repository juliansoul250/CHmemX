"""Offline directory experiment. Four paired controls; never writes an input index.
Standalone CLI accepts ONLY the public synthetic holdout and a new scratch directory.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import random
import subprocess
from unittest.mock import patch

from chmemx import query_plan
from chmemx.service import Service
from chmemx.scripts import retrieval_v3 as search
from metrics import outcome, summarize

MODES=('baseline','no_cells','no_navigation','topic')

def load(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x') as stream:json.dump(value,stream,ensure_ascii=False,indent=2)

def topic_cells(records,nodes):
    """Derived prefix leaves from existing scope-bound node membership only."""
    groups=defaultdict(list);by_uid={n['uid']:n for n in nodes};linked=defaultdict(set)
    for n in nodes:
        for rid in n['record_ids']:linked[rid].add(n['uid'])
    for r in records:groups[(r['project_id'],r['key'].rsplit('.',1)[0])].append(r)
    cells=[]
    for (pid,parent),group in sorted(groups.items(),key=lambda pair:str(pair[0])):
        ids={r['id']:r['key'] for r in group}; by_members=defaultdict(set)
        # Broad/singleton nodes don't partition this prefix. Reject ambiguous key matches.
        if len(set(ids.values()))==len(ids):
            for rid in ids:
                for uid in linked[rid]:by_members[uid].add(rid)
        cover=set(); seen=set()
        def append(label,identity,member_ids,keywords,aliases):
            cells.append({'id':'cell-'+search.digest(identity)[:20],'title':label,'scope':'global' if pid is None else 'project','project_id':pid,'keywords':list(keywords),'aliases':list(aliases),'member_keys':sorted(ids[rid] for rid in member_ids),'related_cell_ids':[]})
        for uid,member_ids in sorted(by_members.items()):
            members=frozenset(member_ids)
            if not 1<len(members)<len(ids) or members in seen:continue
            seen.add(members);cover.update(members);n=by_uid[uid]
            append(n['title'],[pid,parent,uid],members,n['keywords'],n['aliases'])
        residual=set(ids)-cover
        if residual:append(parent,[pid,parent],residual,[parent],[])
    return cells

def no_navigation(reader,raw):
    """Fixed baseline IDF. The canonical reader still verifies original record bytes."""
    index=reader.lexical;index['cells']=[];index['nodes']=[]
    weights=search.lexical.feature_weight_map(index);dim=index['vectorizer']['dimensions']
    for meta in index['records']:
        rid=meta['id'];bare={**raw[rid],'hints':[],'node_uids':[]}
        meta.update(hints=[],node_uids=[],vector=search.lexical.sparse_vector(search.lexical.record_vector_texts(bare,{}),dim,weights))
        reader.navigation_terms[rid]=set(search.lexical.text_tokens(meta['key']))

def gate(groups):
    for suite,rows in groups.items():
        b,t=rows['baseline'],rows['topic']
        if any(r['scope'] or r['errors'] for r in rows.values()):return False
        if any(t[k]<b[k] for k in ('complete','positive','multi')):return False
        if suite=='new' and (t['complete']<=b['complete'] or t['exact']<b['exact'] or t['false_returns']>b['false_returns']):return False
    return 'new' in groups

def cases_new(fixture,questions,plans):
    records=fixture['records'];cases=fixture['cases'];rs={r['id']:r for r in records}; langs=lambda s:bool(__import__('re').search(r'[\u3400-\u9fff]',s))
    assert len(rs)==len(records)==12 and len({r['topic'] for r in records})==4
    assert len({c['id'] for c in cases})==len({c['query'] for c in cases})==24 and sum(langs(r['body']) for r in records)==6
    assert Counter(c['category'] for c in cases)=={'direct':6,'paraphrase':4,'multi_intent':4,'conditional':2,'no_answer':8}
    assert Counter(c['language'] for c in cases)=={'en':12,'zh':12}
    assert questions==[{k:c[k] for k in ('id','query')} for c in cases]
    assert [q['id'] for q in questions]==[p['id'] for p in plans] and all(p['plan']['query']==q['query'] for q,p in zip(questions,plans))
    assert sum(any(langs(rs[k]['body'])!=(c['language']=='zh') for k in c['expected_all']) for c in cases)>=6
    for c in cases:
        assert bool(c['expected_all'])==(c['category']!='no_answer') and (c['category']!='multi_intent' or len(set(c['expected_all']))==2)
        assert set(c['expected_all']+c['forbidden'])<=rs.keys() and not (set(c['expected_all'])&set(c['forbidden']))
    return records,cases,{p['id']:p['plan'] for p in plans}

def sandbox_new(work,model,records):
    project=work/'project';store=work/'store';assert not project.exists() and not store.exists()
    project.mkdir(parents=True);subprocess.run(['git','init','-q',str(project)],check=True)
    who='tree-synthetic-fixture';svc=Service(store,project,who,model);svc.initialize('project-fixture','team');ids=[];keys={}
    for r in records:
        keys[r['id']]='tree.sample.'+r['id'];nodes=[]
        for uid,title in [('record-'+r['id'],r['title']),('topic-'+search.digest(r['topic'])[:16],r['topic'])]:
            nodes.append({'id':uid,'title':title,'keywords':[title],'aliases':[],'related_node_ids':[]})
        c=svc.runtime.propose({'scope':'global','class':'preference','key':keys[r['id']],'body':r['body'],'source':svc.source({'quote':r['body']},'global'),'submitted_by_agent':who,'nodes':nodes},project);ids.append(c['candidate_id'])
    batch=svc.runtime.create_batch(ids);review=svc.runtime.review(batch['batch_id']);svc.runtime.approve(batch['batch_id'],batch['batch_digest'],review['required_confirmation'],committing_agent=who);svc.rebuild()
    return svc.index_path,project,keys

def compare(name,base_path,cases,plans,keys,cwd_for,work,archive=None):
    work.mkdir(parents=True,exist_ok=False);initial=sha(base_path);base=load(base_path);store=Path(base['memory_graph_store']);model=Path(base['hybrid']['model_directory']);assert search.clean_head(store)==base['memory_graph_head']
    _,rs,ns=search.lexical.collect_active(store);raw={r['id']:r for r in rs};cells=topic_cells(rs,ns);taxonomy=work/'candidate-directory.json';write(taxonomy,{'cells':cells});topic=search.build(store,taxonomy,model,contexts=base['contexts'],previous=base)
    assert topic['bound_files']==base['bound_files'] and topic['hybrid']==base['hybrid'] and not topic['unassigned_record_ids']; assert {r['id']:r['record_sha256'] for r in base['records']}=={r['id']:r['record_sha256'] for r in topic['records']}
    assert all(raw[rid]['project_id']==cell['project_id'] for cell in topic['cells'] for rid in cell['member_record_ids'])
    readers={m:search.Retriever(topic if m=='topic' else base) for m in MODES};readers['no_cells'].lexical['cells']=[];no_navigation(readers['no_navigation'],raw)
    jobs=[(m,c) for m in MODES for c in cases];random.Random(20261118).shuffle(jobs); inverse={key:label for label,key in keys.items()};rows=[]
    for m,c in jobs:
        reader=readers[m];cwd=cwd_for(c);reads=[];entries=[];associations=[];error=None
        try:
            with patch.object(reader,'read',wraps=reader.read) as tracked:
                result=reader.recall(c['query'],cwd,3,0,query_plan=plans[c['id']]);reads=[call.args[0] for call in tracked.call_args_list]
            entries=result['entries'];associations=result['associations'];status=result['status']
            assert not associations and len(reads)==len(set(reads))<=20 and len(entries)<=3
        except (KeyError,ValueError,TypeError) as exc:
            status='ERROR';error=f'{type(exc).__name__}: {exc}'
        allowed=reader.allowed(c['query'],reader.project(cwd));scope=sum(e.get('project_id') not in allowed for e in entries);out=outcome(c,[inverse[e['key']] for e in entries],status);rows.append({**out,'suite':name,'id':c['id'],'mode':m,'category':c['category'],'language':c['language'],'cluster':c['cluster'],'scope':scope,'body_reads':len(reads),'error_reason':error})
    assert sha(base_path)==initial and search.clean_head(store)==base['memory_graph_head']; bmap={r['id']:r for r in rows if r['mode']=='baseline'}
    if archive is not None:
        assert archive.keys()==bmap.keys() and all(r[k]==archive[i][k] for i,r in bmap.items() for k in ('returned','status','exact_match','complete_support'))
    def stats(sel):
        return {**summarize(sel),'complete':sum(r['complete_support'] for r in sel),'positive':sum(r['positive'] and r['complete_support'] for r in sel),'multi':sum(r['category']=='multi_intent' and r['complete_support'] for r in sel),'exact':sum(r['exact_match'] for r in sel),'false_returns':sum(r['category']=='no_answer' and bool(r['returned']) for r in sel),'scope':sum(r['scope'] for r in sel),'changed_lists':sum(r['returned']!=bmap[r['id']]['returned'] for r in sel),'complete_gains':sum(r['complete_support'] and not bmap[r['id']]['complete_support'] for r in sel),'complete_losses':sum(not r['complete_support'] and bmap[r['id']]['complete_support'] for r in sel),'primary_reads':sum(r['body_reads'] for r in sel)}
    groups={m:stats([r for r in rows if r['mode']==m]) for m in MODES};structure={'before_cells':len(base['cells']),'after_cells':len(cells),'before_sizes':[len(c['member_record_ids']) for c in base['cells']],'after_sizes':[len(c['member_record_ids']) for c in topic['cells']],'shared_nodes':sum(len(n['record_ids'])>1 for n in ns),'model_lock_sha256':sha(model/'model-lock.json'),'embeddings_reused':topic['build_statistics']['embedding_chunks_reused'],'embeddings_computed':topic['build_statistics']['embedding_chunks_computed'],'baseline_index_sha256':initial,'derived_directory_sha256':sha(taxonomy),'archive_order_verified':archive is not None}
    for key,val in [('rows',rows),('summary',groups),('structure',structure)]:write(work/(key+'.json'),val)
    print(name, {m:[v[k] for k in ('complete','positive','multi','exact','false_returns','changed_lists','errors','scope')] for m,v in groups.items()},flush=True);return groups

def run_new(fixture,questions,plans,work,model):
    rs,cs,ps=cases_new(load(fixture),load(questions),load(plans));ip,cwd,keys=sandbox_new(work,model,rs);return compare('new',ip,cs,ps,keys,lambda c:cwd,work/'compare')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for name in ('fixture','questions','plans','work','model'):parser.add_argument('--'+name,type=Path,required=True)
    a=parser.parse_args();run_new(a.fixture,a.questions,a.plans,a.work.resolve(),a.model.resolve())
