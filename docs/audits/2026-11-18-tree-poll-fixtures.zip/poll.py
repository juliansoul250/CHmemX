"""Episode harness: actual scoped retrieval on the frozen, synthetic dev store only."""
import json, sys
from pathlib import Path
from chmemx.service import Service
from chmemx import query_plan

ROOT=Path(__file__).resolve().parent
RUNS=('r1','r2','r3')

def load(p):return json.loads(p.read_text())
def once(p,value):
    with p.open('x') as f: json.dump(value,f,ensure_ascii=False,indent=2)

def run(lane):
    out=ROOT/lane; packet=load(ROOT/'packet.json'); frm=load(out/'requests.json'); assert [x['id'] for x in frm]==[q['id'] for q in packet]
    dev=ROOT.parent/'phase5/sandbox/dev'; svc=Service(dev/'store',dev/'project','tree-poll-reader',ROOT.parent/'private-ranking/model');assert svc.index_path.is_file(); reader=svc._reader(); rows=[]
    for q,request in zip(packet,frm):
        assert set(request)=={'id','plan'} and request['plan']['query']==q['query']
        plan=request['plan'];query_plan.validate(q['query'],plan,limit=3,association_limit=0)
        if lane=='r1':assert plan==q['plan']
        if lane!='r1':assert set(q['plan']['entities'])<=set(plan['entities']) and set(q['plan']['constraints'])<=set(plan['constraints'])
        res=reader.recall(q['query'],dev/'project',3,0,query_plan=plan)
        assert not res['associations'];entries=[{'key':e['key'],'body':e['body']} for e in res['entries']];rows.append({'id':q['id'],'query':q['query'],'entries':entries,'status':res['status']})
    once(out/'hits.json', rows); print('executed',lane,len(rows),'synthetic queries')

def check(lane):
    out=ROOT/lane; hits=load(out/'hits.json'); verdicts=load(out/'evidence.json'); assert [r['id'] for r in verdicts]==[q['id'] for q in hits]
    for r,q in zip(verdicts,hits):
        assert set(r)=={'id','status','quotes','gap'} and r['status'] in ('supported','partial','insufficient'); assert isinstance(r['gap'],str)
        assert (r['status']=='supported')== (not r['gap'].strip()); assert r['status']=='insufficient' or r['quotes']; assert r['status']!='insufficient' or not r['quotes']
        bodies={e['key']:e['body'] for e in q['entries']}
        for e in r['quotes']:
            assert set(e)=={'key','quote'} and e['key'] in bodies and bool(e['quote'].strip()) and e['quote'] in bodies[e['key']],(r['id'],e['key'],'non-verbatim evidence')
    print('verified quote provenance',lane,len(hits));return True

if __name__=='__main__':
    action,lane=sys.argv[1:];assert action in ('run','check') and lane in RUNS
    (run if action=='run' else check)(lane)
