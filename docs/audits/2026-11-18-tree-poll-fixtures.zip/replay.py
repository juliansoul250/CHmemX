"""Rebuild synthetic stores and compare per-query outputs with archived measurements."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile

import poll
import tree_eval as tree


HERE = Path(__file__).resolve().parent
ARCHIVES = {
    'small': ('2026-11-18-goal-vector-fixtures.zip',
              'c3f02c3e5b762579dd196015aaf72aa1a75b39a63631c492587fcfe21aff6f84'),
    'large': ('2026-11-17-large-backtest-fixtures.zip',
              '8577bc62321c3459fd9164bfe5f4d2a8e69d2127aa5ac9b7952376c9e154bcb5'),
}


def archived(audits, kind, target, names, script):
    filename, checksum = ARCHIVES[kind]
    source = audits / filename
    assert tree.sha(source) == checksum, f'Mismatch: {source.name}'
    with ZipFile(source) as bundle:
        # Copy only fixed fixture paths + the builder from this exact historical archive.
        for name in [*names, script]:
            dest = target / name
            dest.parent.mkdir(exist_ok=True, parents=True)
            dest.write_bytes(bundle.read(name))
    spec = importlib.util.spec_from_file_location('old_' + kind, target / script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_rows(name, produced):
    def keyed(rows):
        result = {(r['id'], r['mode']): r for r in rows}
        assert len(result) == len(rows)
        return result
    original = keyed(tree.load(HERE / 'evidence' / name / 'rows.json'))
    actual = keyed(tree.load(produced / 'rows.json'))
    assert original.keys() == actual.keys()
    return {'cases_x_configurations': len(actual), 'different_rows': [
        {'id': key[0], 'mode': key[1], 'fields': [k for k in original[key]
         if original[key][k] != actual[key].get(k)]} for key in sorted(original)
        if original[key] != actual[key]]}


def check_rounds(reader, cwd):
    total = 0
    differences = []
    for lane in poll.RUNS:
        poll.check(lane)
        req = tree.load(HERE / lane / 'requests.json')
        hits = tree.load(HERE / lane / 'hits.json')
        assert [r['id'] for r in req] == [h['id'] for h in hits]
        for r, h in zip(req, hits):
            p = r['plan']
            out = reader.recall(p['query'], cwd, 3, 0, query_plan=p)
            actual = [{'key': e['key'], 'body': e['body']} for e in out['entries']]
            total += 1
            if actual != h['entries'] or out['status'] != h['status'] or out['associations']:
                differences.append([lane, r['id']])
    return {'recorded_requests_replayed': total, 'different_responses': differences}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, required=True, help='Existing locked local model')
    parser.add_argument('--work', type=Path, required=True, help='New, nonexistent scratch path')
    parser.add_argument('--audits', type=Path, help='Directory containing both historical public ZIPs; omit for new 24 only')
    args = parser.parse_args()
    work, model = args.work.resolve(), args.model.resolve()
    assert not work.exists(), 'Refusing to reuse a directory; pass a new scratch path.'
    for name, digest in tree.load(HERE / 'manifest.json').items():
        assert tree.sha(HERE / name) == digest, name
    binding = tree.load(HERE / 'replay-binding.json')
    assert tree.sha(model / 'model-lock.json') == binding['inputs']['model_lock']
    for path, field in [(Path(tree.__file__), 'harness'), (Path(tree.search.__file__), 'ranker'),
                        (Path(tree.search.lexical.__file__), 'scorer'), (HERE / 'metrics.py', 'metrics')]:
        assert tree.sha(path) == binding[field], f'Frozen {field} differs; exact replay requires audited code.'
    import inspect
    assert tree.sha(Path(inspect.getfile(tree.Service))) == binding['service'], 'Frozen service differs.'
    work.mkdir(parents=True)
    report = {}
    tree.run_new(HERE / 'author/fixture.json', HERE / 'author/questions.json',
                 HERE / 'planner/plans.json', work / 'new', model)
    report['new'] = check_rows('new', work / 'new/compare')
    if args.audits:
        small = archived(args.audits, 'small', work / 'historical-small', [
            f'{split}/{f}' for split in ('dev', 'holdout') for f in ('fixture.json', 'questions.json')
        ] + [f'plan-{split}/plans.json' for split in ('dev', 'holdout')], 'experiment.py')
        for split in ('dev', 'holdout'):
            records, cases, plans = small.inputs(split)
            reader, cwd, keys = small.sandbox(split, records, model)
            index = cwd.parent / 'store/.queue/chmemx/index.json'
            tree.compare(split, index, cases, plans, keys, lambda _: cwd, work / split)
            report[split] = check_rows(split, work / split)
            if split == 'dev':
                report['rounds'] = check_rounds(reader, cwd)
        # The published historical module reads these at import time. Only inputs()
        # and prepare() are used; nothing is installed, fetched or written in the repo.
        with patch.dict(os.environ, {'CHMEMX_REPO': str(args.audits.resolve()),
                                     'CHMEMX_MODEL_DIR': str(model)}):
            large = archived(args.audits, 'large', work / 'historical-large', [
                f'authors/{lane}/{f}' for lane in ('a', 'b')
                for f in ('fixture.json', 'questions-only.json', 'freeze.json')
            ] + [f'planners/{lane}/plans.json' for lane in ('a', 'b')], 'run.py')
        rs, cases, plans, _, errors = large.inputs()
        assert not errors
        _, cwds, index = large.prepare(rs)
        tree.compare('large', index, cases, plans, {r['key']: r['key'] for r in rs},
                     lambda c: cwds[c['project'] or 'outside'], work / 'large')
        report['large'] = check_rows('large', work / 'large')
    tree.write(work / 'replay.json', report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if any(row.get('different_rows') or row.get('different_responses') for row in report.values()):
        raise SystemExit('Replay differences: see replay.json.')


if __name__ == '__main__':
    main()
